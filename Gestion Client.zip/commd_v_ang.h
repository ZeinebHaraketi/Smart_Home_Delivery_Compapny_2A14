#ifndef COMMD_V_ANG_H
#define COMMD_V_ANG_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <iostream>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlError>
#include <QTime>
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QTime>
#include "GestionClient_ComdV.h"
#include "ui_GestionClient_ComdV.h"
#include "commandesv.h"

class COMMD_V_ANG
{

private:

    int ID_COMMDV;
    QString name_Product;
    int Price;
    QString Date_M;

public:

    //The Constructor:
    COMMD_V_ANG();
    COMMD_V_ANG(int,QString,int,QString);

    //The Getters:
    int get_IDCOMMDV(){return ID_COMMDV;}
    QString get_nameProduct(){return name_Product;}
    int get_Price(){return Price;}
    QString get_DateM(){return Date_M;}

    //The Setters
    void set_IDCOMMDV(int);
    void set_nameProduct(QString);
    void set_Price(int);
    void set_DateM(QString);

   //Basic Methodes ------> CRUD
      bool ADD_CommDV();
      QSqlQueryModel * DISPLAY_CommDV();
      bool Remove_CommDV(Ui::GestionClient_ComdV *ui);
      bool Modify_CommDV(Ui::GestionClient_ComdV *ui);

      // Métiers
      void SearchCommandes(int idv);
      QSqlQueryModel * SortCommandes(QString);
};

#endif // COMMD_V_ANG_H
