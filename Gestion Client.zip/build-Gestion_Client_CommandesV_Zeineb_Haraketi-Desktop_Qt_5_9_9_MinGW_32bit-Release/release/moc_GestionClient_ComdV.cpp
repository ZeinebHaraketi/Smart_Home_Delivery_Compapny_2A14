/****************************************************************************
** Meta object code from reading C++ file 'GestionClient_ComdV.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Gestion_Client_CommandesV_Zeineb_Haraketi/GestionClient_ComdV.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GestionClient_ComdV.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GestionClient_ComdV_t {
    QByteArrayData data[38];
    char stringdata0[810];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GestionClient_ComdV_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GestionClient_ComdV_t qt_meta_stringdata_GestionClient_ComdV = {
    {
QT_MOC_LITERAL(0, 0, 19), // "GestionClient_ComdV"
QT_MOC_LITERAL(1, 20, 30), // "on_pushButton_ajouter1_clicked"
QT_MOC_LITERAL(2, 51, 0), // ""
QT_MOC_LITERAL(3, 52, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(4, 76, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(5, 100, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(6, 124, 27), // "on_comboBox_trier_activated"
QT_MOC_LITERAL(7, 152, 25), // "on_Refresh_Client_clicked"
QT_MOC_LITERAL(8, 178, 15), // "on_Next_clicked"
QT_MOC_LITERAL(9, 194, 29), // "on_pushButton_ajouter_clicked"
QT_MOC_LITERAL(10, 224, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(11, 248, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(12, 272, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(13, 294, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(14, 318, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(15, 342, 24), // "on_comboBox_20_activated"
QT_MOC_LITERAL(16, 367, 18), // "on_Refresh_clicked"
QT_MOC_LITERAL(17, 386, 19), // "on_Previous_clicked"
QT_MOC_LITERAL(18, 406, 16), // "on_Next2_clicked"
QT_MOC_LITERAL(19, 423, 14), // "on_ADD_clicked"
QT_MOC_LITERAL(20, 438, 17), // "on_Modify_clicked"
QT_MOC_LITERAL(21, 456, 17), // "on_Remove_clicked"
QT_MOC_LITERAL(22, 474, 21), // "on_Actualiser_clicked"
QT_MOC_LITERAL(23, 496, 17), // "on_Search_clicked"
QT_MOC_LITERAL(24, 514, 20), // "on_Sort_by_activated"
QT_MOC_LITERAL(25, 535, 20), // "on_Previous1_clicked"
QT_MOC_LITERAL(26, 556, 16), // "on_Next1_clicked"
QT_MOC_LITERAL(27, 573, 21), // "on_ADD_COMMDV_clicked"
QT_MOC_LITERAL(28, 595, 25), // "on_Refresh_Co_ANG_clicked"
QT_MOC_LITERAL(29, 621, 22), // "on_ModifyCom_A_clicked"
QT_MOC_LITERAL(30, 644, 23), // "on_Search_Com_A_clicked"
QT_MOC_LITERAL(31, 668, 18), // "on_Remove2_clicked"
QT_MOC_LITERAL(32, 687, 27), // "on_comboBox_SortC_activated"
QT_MOC_LITERAL(33, 715, 17), // "on_Return_clicked"
QT_MOC_LITERAL(34, 733, 16), // "on_PRINT_clicked"
QT_MOC_LITERAL(35, 750, 20), // "on_Print_PDF_clicked"
QT_MOC_LITERAL(36, 771, 19), // "on_Francais_clicked"
QT_MOC_LITERAL(37, 791, 18) // "on_Anglais_clicked"

    },
    "GestionClient_ComdV\0on_pushButton_ajouter1_clicked\0"
    "\0on_pushButton_5_clicked\0"
    "on_pushButton_4_clicked\0on_pushButton_6_clicked\0"
    "on_comboBox_trier_activated\0"
    "on_Refresh_Client_clicked\0on_Next_clicked\0"
    "on_pushButton_ajouter_clicked\0"
    "on_pushButton_7_clicked\0on_pushButton_8_clicked\0"
    "on_pushButton_clicked\0on_pushButton_2_clicked\0"
    "on_pushButton_3_clicked\0"
    "on_comboBox_20_activated\0on_Refresh_clicked\0"
    "on_Previous_clicked\0on_Next2_clicked\0"
    "on_ADD_clicked\0on_Modify_clicked\0"
    "on_Remove_clicked\0on_Actualiser_clicked\0"
    "on_Search_clicked\0on_Sort_by_activated\0"
    "on_Previous1_clicked\0on_Next1_clicked\0"
    "on_ADD_COMMDV_clicked\0on_Refresh_Co_ANG_clicked\0"
    "on_ModifyCom_A_clicked\0on_Search_Com_A_clicked\0"
    "on_Remove2_clicked\0on_comboBox_SortC_activated\0"
    "on_Return_clicked\0on_PRINT_clicked\0"
    "on_Print_PDF_clicked\0on_Francais_clicked\0"
    "on_Anglais_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GestionClient_ComdV[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      36,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  194,    2, 0x08 /* Private */,
       3,    0,  195,    2, 0x08 /* Private */,
       4,    0,  196,    2, 0x08 /* Private */,
       5,    0,  197,    2, 0x08 /* Private */,
       6,    0,  198,    2, 0x08 /* Private */,
       7,    0,  199,    2, 0x08 /* Private */,
       8,    0,  200,    2, 0x08 /* Private */,
       9,    0,  201,    2, 0x08 /* Private */,
      10,    0,  202,    2, 0x08 /* Private */,
      11,    0,  203,    2, 0x08 /* Private */,
      12,    0,  204,    2, 0x08 /* Private */,
      13,    0,  205,    2, 0x08 /* Private */,
      14,    0,  206,    2, 0x08 /* Private */,
      15,    0,  207,    2, 0x08 /* Private */,
      16,    0,  208,    2, 0x08 /* Private */,
      17,    0,  209,    2, 0x08 /* Private */,
      18,    0,  210,    2, 0x08 /* Private */,
      19,    0,  211,    2, 0x08 /* Private */,
      20,    0,  212,    2, 0x08 /* Private */,
      21,    0,  213,    2, 0x08 /* Private */,
      22,    0,  214,    2, 0x08 /* Private */,
      23,    0,  215,    2, 0x08 /* Private */,
      24,    0,  216,    2, 0x08 /* Private */,
      25,    0,  217,    2, 0x08 /* Private */,
      26,    0,  218,    2, 0x08 /* Private */,
      27,    0,  219,    2, 0x08 /* Private */,
      28,    0,  220,    2, 0x08 /* Private */,
      29,    0,  221,    2, 0x08 /* Private */,
      30,    0,  222,    2, 0x08 /* Private */,
      31,    0,  223,    2, 0x08 /* Private */,
      32,    0,  224,    2, 0x08 /* Private */,
      33,    0,  225,    2, 0x08 /* Private */,
      34,    0,  226,    2, 0x08 /* Private */,
      35,    0,  227,    2, 0x08 /* Private */,
      36,    0,  228,    2, 0x08 /* Private */,
      37,    0,  229,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GestionClient_ComdV::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GestionClient_ComdV *_t = static_cast<GestionClient_ComdV *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_ajouter1_clicked(); break;
        case 1: _t->on_pushButton_5_clicked(); break;
        case 2: _t->on_pushButton_4_clicked(); break;
        case 3: _t->on_pushButton_6_clicked(); break;
        case 4: _t->on_comboBox_trier_activated(); break;
        case 5: _t->on_Refresh_Client_clicked(); break;
        case 6: _t->on_Next_clicked(); break;
        case 7: _t->on_pushButton_ajouter_clicked(); break;
        case 8: _t->on_pushButton_7_clicked(); break;
        case 9: _t->on_pushButton_8_clicked(); break;
        case 10: _t->on_pushButton_clicked(); break;
        case 11: _t->on_pushButton_2_clicked(); break;
        case 12: _t->on_pushButton_3_clicked(); break;
        case 13: _t->on_comboBox_20_activated(); break;
        case 14: _t->on_Refresh_clicked(); break;
        case 15: _t->on_Previous_clicked(); break;
        case 16: _t->on_Next2_clicked(); break;
        case 17: _t->on_ADD_clicked(); break;
        case 18: _t->on_Modify_clicked(); break;
        case 19: _t->on_Remove_clicked(); break;
        case 20: _t->on_Actualiser_clicked(); break;
        case 21: _t->on_Search_clicked(); break;
        case 22: _t->on_Sort_by_activated(); break;
        case 23: _t->on_Previous1_clicked(); break;
        case 24: _t->on_Next1_clicked(); break;
        case 25: _t->on_ADD_COMMDV_clicked(); break;
        case 26: _t->on_Refresh_Co_ANG_clicked(); break;
        case 27: _t->on_ModifyCom_A_clicked(); break;
        case 28: _t->on_Search_Com_A_clicked(); break;
        case 29: _t->on_Remove2_clicked(); break;
        case 30: _t->on_comboBox_SortC_activated(); break;
        case 31: _t->on_Return_clicked(); break;
        case 32: _t->on_PRINT_clicked(); break;
        case 33: _t->on_Print_PDF_clicked(); break;
        case 34: _t->on_Francais_clicked(); break;
        case 35: _t->on_Anglais_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject GestionClient_ComdV::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_GestionClient_ComdV.data,
      qt_meta_data_GestionClient_ComdV,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *GestionClient_ComdV::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GestionClient_ComdV::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GestionClient_ComdV.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int GestionClient_ComdV::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 36)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 36)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 36;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
