#ifndef GESTIONCLIENT_COMDV_H
#define GESTIONCLIENT_COMDV_H
#include <QMainWindow>
#include <QLineEdit>
#include <QTabWidget>
#include <QToolBox>
#include <QtWidgets/QGridLayout>
#include <QMap>
#include <QVector>
#include <QtCharts/QLineSeries>
#include <QtWidgets>
#include <QSystemTrayIcon>
#include "commandesv.h"
#include "commd_v_ang.h"
#include "client.h"
#include "clientanglais.h"
#include <QPropertyAnimation>


QT_BEGIN_NAMESPACE
namespace Ui { class GestionClient_ComdV; }
QT_END_NAMESPACE

class GestionClient_ComdV : public QMainWindow
{
    Q_OBJECT



public:
    GestionClient_ComdV(QWidget *parent = nullptr);
    //MainWindow(QDialog *parent = nullptr);
    ~GestionClient_ComdV();

 private slots:
    //------------ Client--------------//
    //--------- Ajout--------------------//

    void on_pushButton_ajouter1_clicked();


    //---------- Afficher---------------//


   void on_pushButton_5_clicked();//modifier
   void on_pushButton_4_clicked();//rechercher
   void on_pushButton_6_clicked();//supprimer

   void on_comboBox_trier_activated();//trier client
   void on_Refresh_Client_clicked();//refresh client
   void on_Next_clicked(); //aller à la page suivante

    //----------- CommandesV--------------------//


     void on_pushButton_ajouter_clicked();//ajouter Command


     void on_pushButton_7_clicked(); //imprimer Doc
     void on_pushButton_8_clicked(); //imprimer Pdf

           void on_pushButton_clicked();// rechercher Command
           void on_pushButton_2_clicked();// modifier Command
           void on_pushButton_3_clicked();// supprimer Command

        void on_comboBox_20_activated(); //trier
        void on_Refresh_clicked();//refresh

        void on_Previous_clicked();// previously
        void on_Next2_clicked(); // aller à la page suivante



        //*******--------------------------------- English Version ------------------------------******//

        //----------------------------- CLIENT---------------------------//

        //************************************* ADD CLIENT*********************//

                          void on_ADD_clicked();

        //************************************* MODIFY CLIENT*********************//
                         void on_Modify_clicked();


        //************************************* REMOVE CLIENT*********************//
                          void on_Remove_clicked();

                          //Refresh//
                         void on_Actualiser_clicked();
                          //Search//
                         void on_Search_clicked();
                          //Sort By
                         void on_Sort_by_activated();
                         // Previously
                         void on_Previous1_clicked();
                         // Next Page//
                         void on_Next1_clicked();

        //--------------------- PRODUCT----------------------------------//

          //************************************* ADD COMMDV *********************//

                         void on_ADD_COMMDV_clicked();
                         // refresh//
                         void on_Refresh_Co_ANG_clicked();

           //************************************* MODIFY COMMDV*********************//
                        void on_ModifyCom_A_clicked();
                         //search//
                         void on_Search_Com_A_clicked();

           //************************************* REMOVE COMMDV*********************//
                         void on_Remove2_clicked();

                         //Sort By
                         void on_comboBox_SortC_activated();
                         // previously
                         void on_Return_clicked();
                         // PRINT AS DOC
                        void on_PRINT_clicked();
                         //PRINT AS PDF
                         void on_Print_PDF_clicked();

           //********************************* CHOOSE A LANGUAGE *****************************//
                         //Francais//
                         void on_Francais_clicked();
                         //Anglais//
                         void on_Anglais_clicked();
private:
    Ui::GestionClient_ComdV *ui;
    QPropertyAnimation *animation;



};
#endif // GESTIONCLIENT_COMDV_H
