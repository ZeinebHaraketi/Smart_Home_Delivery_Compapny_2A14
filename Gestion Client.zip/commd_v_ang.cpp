#include "commd_v_ang.h"
#include "connection.h"
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QMessageBox>
#include <QtDebug>
#include <QDebug>

COMMD_V_ANG::COMMD_V_ANG()
{
   ID_COMMDV=0;
   name_Product="";
   Price=0;
   Date_M="";
}

COMMD_V_ANG::COMMD_V_ANG(int idv,QString na,int pr,QString date){
    this->ID_COMMDV= idv;
    this->name_Product= na;
    this->Price= pr;
    this->Date_M= date;
}

//The Setters//
void COMMD_V_ANG::set_IDCOMMDV(int idv){ID_COMMDV=idv;}
void COMMD_V_ANG::set_nameProduct(QString name){name_Product=name;}
void COMMD_V_ANG::set_Price(int pr){Price=pr;}
void COMMD_V_ANG::set_DateM(QString date){Date_M=date;}

//------------------------------------ ADD COMMDV---------------------------------------------------//

bool COMMD_V_ANG::ADD_CommDV(){
    QSqlQuery query4;

    query4.prepare(" INSERT INTO COMMANDESVENTE(ID_COMMANDESVENTE,NOM_PRODUIT,PRIX,DATE_FABRICATION)" "VALUES(:ID_COMMDV,:name_Product,:Price,:Date_M)");

    query4.bindValue(":ID_COMMDV",get_IDCOMMDV());
    query4.bindValue(":name_Product",get_nameProduct());
    query4.bindValue(":Price",get_Price());
    query4.bindValue(":Date_M",get_DateM());


    return query4.exec();
}


//-------------------------------- DISPLAY COMMDV-------------------------------------------//
QSqlQueryModel * COMMD_V_ANG::DISPLAY_CommDV(){

    QSqlQueryModel *model=new QSqlQueryModel();
    model->setQuery("SELECT * FROM COMMANDESVENTE ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COMMDV"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("name_Product"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Price"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Date_M"));
    return model;
}

//---------------------------------- SEARCH COMMDV---------------------------------------//
void COMMD_V_ANG::SearchCommandes(int idv){

    QSqlQuery query4;

    query4.prepare("SELECT * FROM COMMANDESVENTE WHERE Id_CommandesVente= '"+QString::number(idv)+"'");
    query4.exec();

    while(query4.next()){
        ID_COMMDV= query4.value(0).toInt();
        name_Product= query4.value(1).toString();
        Price= query4.value(2).toInt();
        Date_M= query4.value(3).toString();
    }

}

//----------------------------- MODIFY COMMDV----------------------------------------------------//

bool COMMD_V_ANG::Modify_CommDV(Ui::GestionClient_ComdV *ui){
    int idv= ui->lineEdit_IDV_2->text().toInt();
    QString name1= ui->lineEdit_Name_2->text();
    int price= ui->lineEdit_Price_2->text().toInt();
    QString dateM= ui->l_DateM_2->text();

    COMMD_V_ANG CA(idv,name1,price,dateM);

    QSqlQuery query4;

    query4.prepare(" UPDATE COMMANDESVENTE SET NOM_PRODUIT ='"+name1+"', PRIX= '"+QString::number(price)+"',DATE_FABRICATION='"+dateM+"' WHERE ID_COMMANDESVENTE= '"+QString::number(idv)+"'");
    query4.bindValue(":ID_COMMDV",get_IDCOMMDV());
    query4.bindValue(":name_Product",get_nameProduct());
    query4.bindValue(":Price",get_Price());
    query4.bindValue(":Date_M",get_DateM());

    return query4.exec();
}


//--------------------------------- REMOVE COMMDV-------------------------------------------------//

bool COMMD_V_ANG::Remove_CommDV(Ui::GestionClient_ComdV *ui){

    int idv= ui->lineEdit_IDV_3->text().toInt();
    COMMD_V_ANG CA(idv,"",0,"");

    QSqlQuery query4;

    query4.prepare(" DELETE  From COMMANDESVENTE  WHERE Id_CommandesVente= "+QString::number(idv)+" ");
    query4.bindValue(":ID_COMMDV",get_IDCOMMDV());
    query4.bindValue(":name_Product",get_nameProduct());
    query4.bindValue(":Price",get_Price());
    query4.bindValue(":Date_M",get_DateM());

    return query4.exec();
}

//------------------------------ SORT COMMDV----------------------------------------------//

QSqlQueryModel * COMMD_V_ANG::SortCommandes(QString choice1){
    QSqlQueryModel *model=new QSqlQueryModel();

    if(choice1=="ID_COMMDV"){
         model->setQuery("SELECT * FROM COMMANDESVENTE ORDER BY ID_COMMANDESVENTE ASC ");
    }
    else if("name_Product"){
        model->setQuery("SELECT * FROM COMMANDESVENTE ORDER BY NOM_PRODUIT ");
    }
    else if(choice1=="Price"){
         model->setQuery("SELECT * FROM COMMANDESVENTE ORDER BY PRIX ASC ");
    }
    else if(choice1=="Date_M"){
          model->setQuery("SELECT * FROM COMMANDESVENTE ORDER BY DATE_FABRICATION ");
    }
    else if(choice1=="Sort By"){
        model->setQuery("SELECT * FROM COMMANDESVENTE");
    }
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_COMMDV"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("name_Product"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Price"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Date_M"));

 return model;
}
